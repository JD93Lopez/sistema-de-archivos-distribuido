@javax.xml.bind.annotation.XmlSchema(namespace = "http://central/")
package backend_cliente.generated;
