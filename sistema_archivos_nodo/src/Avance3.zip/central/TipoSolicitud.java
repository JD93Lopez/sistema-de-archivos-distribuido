package central;

public enum TipoSolicitud {
    CREAR_DIRECTORIO,
    ALMACENAR,  
    LEER,
    MOVER,
    ELIMINAR,
    COMPARTIR
}